/*
 * Class: CMSC203 
 * Instructor: Dr. Tarek
 * Description: TwoDimRaggedArrayUtility reads file, writes file, and finds different types of useful 
 * information from a two dimensional ragged array  
 * Due: 11/14/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: __Akhil Gunda________
*/

import java.util.Scanner;

import static org.junit.Assert.assertEquals;

import java.io.*;

public class TwoDimRaggedArrayUtility {
	
	//reads files rows and columns into a two dimensional ragged array
	public static double[][] readFile(File dataFile) throws FileNotFoundException{

		//the array we will be returning
		double[][] twoDimRag;
		
		//create scanner object to read from file
		Scanner readFile = new Scanner(dataFile);
		Scanner readFile2 = new Scanner(dataFile);
		
		//we have to get numOfRows to declare array;
		int numOfRows = 0;		
		//this for loop counts # of rows
		for (int i = 0; readFile.hasNext(); i++) {
			if (readFile.hasNextLine()) {
				numOfRows = numOfRows + 1;
				readFile.nextLine();
			}
		}
		readFile.close();
		//declaring num of rows in array
		twoDimRag = new double[numOfRows][];
	
		//loop through rows
		for (int i =0; i < numOfRows; i++) {
			if (readFile2.hasNextLine()) {
				//to store all values in row
				String[] tempCol = readFile2.nextLine().split(" ");
				//the number of values in row equals number of columns
				int colLength = tempCol.length;
				//declare how many columns in each row
				twoDimRag[i] = new double[colLength];
				
				//loop through column
				for (int j = 0; j < colLength; j++) {
					//store values as doubles in array
					twoDimRag[i][j] = Double.parseDouble(tempCol[j]);
				}
			}
		}
		readFile2.close();
		return twoDimRag;
	}
	
	//writes a 2d ragged array to file
	public static void writeToFile(double[][] twoDimRag, File dataFile) throws FileNotFoundException{
		//create print writer object to write to file
		PrintWriter writeFile = new PrintWriter(dataFile);
		
		//number of rows
		int numOfRows = twoDimRag.length;
		
		//loop through row of two dimensional ragged array
		for (int rows =0; rows < numOfRows; rows++) {
			//number of colums for each row
			int numOfCols = twoDimRag[rows].length;
			//loop through colums
			for (int cols = 0; cols < numOfCols; cols++) {
				//print element seperated by space
				writeFile.print(twoDimRag[rows][cols] + " ");
			}
			//once elements of row printer, print new line
			writeFile.println();
		}
		writeFile.close();
	}
	
	public static double getTotal (double[][]twoDimRag) {
		
		//double variable to hold total of all elements
		double twoDimRagTotal = 0;
		
		//number of rows
		int numOfRows = twoDimRag.length;
		
		//loop through rows
		for(int rows = 0; rows < numOfRows; rows++) {
			//number of columns for row
			int numOfCols = twoDimRag[rows].length;
			//loop through columns
			for(int cols = 0; cols < numOfCols; cols++) {
				//get each element
				double element = twoDimRag[rows][cols];
				// add each element to total
				twoDimRagTotal += element;
			}
		}
		return twoDimRagTotal;
	}
	
	public static double getAverage (double[][] twoDimRag) {
		// double variable to hold total of all elements
		double twoDimRagTotal = 0;
		
		//integer variable to count number of elements
		int numOfElements = 0;
		
		// number of rows
		int numOfRows = twoDimRag.length;

		// loop through rows
		for (int rows = 0; rows < numOfRows; rows++) {
			// number of columns for row
			int numOfCols = twoDimRag[rows].length;
			// loop through columns
			for (int cols = 0; cols < numOfCols; cols++) {
				// get each element
				double element = twoDimRag[rows][cols];
				// add each element to total
				twoDimRagTotal += element;
				
				//increase count everytime added
				numOfElements++;
			}
		}
		//average equals total sum of all elements divided by num of elements
		double average = twoDimRagTotal/ numOfElements;
		//return average
		return average;
	}
	
	public static double getRowTotal(double[][]twoDimRag, int rowIndex) {
		
		//declare double to store row total
		double rowTotal  = 0;
		
		//number of columns in row index row
		int numOfCols = twoDimRag[rowIndex].length;
		
		//loop through rowIndex
		for (int row = rowIndex; row == rowIndex; row++) {
			//loop through cols in rowIndex
			for (int cols = 0; cols < numOfCols; cols++) {
				double rowElement = twoDimRag[row][cols];
				rowTotal += rowElement;
			}
		}
		return rowTotal;
	}
	
	public static double getColumnTotal(double[][] twoDimRag, int colIndex) {
		// declare double to store col total
		double colTotal = 0;
		
		//number of rows in col index
		int numOfRows = twoDimRag.length;

		// loop through rows
		for (int row = 0; row < numOfRows; row++) {
			// loop through col index
			for (int cols = colIndex; cols == colIndex; cols++) {
				//if row doesn't contain column, go to next row
				if (cols >= twoDimRag[row].length) {
					continue;
				}
				else {
					//add col total
					double colElement = twoDimRag[row][cols];
					colTotal += colElement;
				}
			}
		}
		return colTotal;
	}
	
	public static double getHighestInRow(double[][] twoDimRag, int rowIndex) {
		//to store highest in row
		double highestInRow = -987654321;
		
		//number of colums in row index
		int numOfCols= twoDimRag[rowIndex].length;
		
		//loop through the row
		for (int rows =rowIndex; rows <= rowIndex; rows++)
		{
			//loop through the column
			for (int cols = 0; cols < numOfCols; cols++) {
				//check if element is greater than highest in row
				if (twoDimRag[rows][cols] > highestInRow) {
					//if it is, then make it the new highest
					highestInRow = twoDimRag[rows][cols];
				}
			}
		}
		return highestInRow;
	}
	
	public static double getHighestInRowIndex(double[][]twoDimRag, int rowIndex) {
		// to store highest in row
		double highestInRow = -987654321;
		double highestInRowIndex = -987654321;

		// number of columns in row index
		int numOfCols = twoDimRag[rowIndex].length;

		// loop through the row
		for (int rows = rowIndex; rows == rowIndex; rows++) {
			// loop through the column
			for (int cols = 0; cols < numOfCols; cols++) {
				// check if element is greater than highest in row
				if (twoDimRag[rows][cols] > highestInRow) {
					// if it is, then make it the new highest
					highestInRow = twoDimRag[rows][cols];
					//store index value of highest element
					highestInRowIndex = cols;
				}
			}
		}
		return highestInRowIndex;
	}
	
	public static double getLowestInRow (double[][] twoDimRag, int rowIndex) {
		
		//to store store lowest in row
		double lowestInRow = 987654321;
		
		// number of columns in row index
		int numOfCols = twoDimRag[rowIndex].length;

		// loop through the row
		for (int rows = rowIndex; rows == rowIndex; rows++) {
			// loop through the column
			for (int cols = 0; cols < numOfCols; cols++) {
				// check if element is smaller than smallest in row
				if (twoDimRag[rows][cols] < lowestInRow) {
					// if it is, then make it the new lowest
					lowestInRow = twoDimRag[rows][cols];
				}
			}
		}
		return lowestInRow;
	}
	
	public static double getLowestInRowIndex (double[][] twoDimRag, int rowIndex) {
		//to store store lowest in row
		double lowestInRow = 987654321;
		double lowestInRowIndex = 987654321;
		
		// number of columns in row index
		int numOfCols = twoDimRag[rowIndex].length;

		// loop through the row
		for (int rows = rowIndex; rows == rowIndex; rows++) {
			// loop through the column
			for (int cols = 0; cols < numOfCols; cols++) {
				// check if element is smaller than smallest in row
				if (twoDimRag[rows][cols] < lowestInRow) {
					// if it is, then make it the new lowest
					lowestInRow = twoDimRag[rows][cols];
					//store index value of element
					lowestInRowIndex = cols;
				}
			}
		}
		return lowestInRowIndex;
	}
	
	public static double getHighestInColumn(double[][] twoDimRag, int colIndex) {
		
		//stores highest value in column
		double highestInColumn = -987654321;
		
		//number of rows
		int numOfRows = twoDimRag.length;
		
		//loop through row
		for(int rows=0; rows< numOfRows; rows++) {
			
			//loop through column
			for (int cols = colIndex; cols == colIndex; cols++) {
				//check to make sure column exist for row
				if (twoDimRag[rows].length <= colIndex) {
					continue;
				}
				//if exists
				else 
				{
					//find highest value
					if (twoDimRag[rows][cols]>highestInColumn) {
						highestInColumn = twoDimRag[rows][cols];
					}
				}
			}
		}
		return highestInColumn;
	}
	
	public static double getHighestInColumnIndex(double[][] twoDimRag, int colIndex) {
		// stores highest value in column
		double highestInColumn = -987654321;
		//stores highest value's index
		double highestInColumnIndex = -987654321;

		// number of rows
		int numOfRows = twoDimRag.length;

		// loop through row
		for (int rows = 0; rows < numOfRows; rows++) {

			// loop through column
			for (int cols = colIndex; cols == colIndex; cols++) {
				// check to make sure column exist for row
				if (twoDimRag[rows].length <= colIndex) {
					continue;
				}
				// if exists
				else {
					// find highest value & store its index
					if (twoDimRag[rows][cols] > highestInColumn) {
						highestInColumn = twoDimRag[rows][cols];
						highestInColumnIndex = rows;
					}
				}
			}
		}
		return highestInColumnIndex;
	}
	
	public static double getLowestInColumn(double[][] twoDimRag, int colIndex) {
		// stores lowest value in column
		double lowestInColumn = 987654321;

		// number of rows
		int numOfRows = twoDimRag.length;

		// loop through row
		for (int rows = 0; rows < numOfRows; rows++) {

			// loop through column
			for (int cols = colIndex; cols == colIndex; cols++) {
				// check to make sure column exist for row
				if (twoDimRag[rows].length <= colIndex) {
					continue;
				}
				// if exists
				else {
					// find lowest value
					if (twoDimRag[rows][cols] < lowestInColumn) {
						lowestInColumn = twoDimRag[rows][cols];
					}
				}
			}
		}
		return lowestInColumn;
	}
	
	public static double getLowestInColumnIndex(double[][] twoDimRag, int colIndex) {
		// stores lowest value in column
		double lowestInColumn = 987654321;
		//store lowest value's index;
		double lowestInColumnIndex = 987654321;

		// number of rows
		int numOfRows = twoDimRag.length;

		// loop through row
		for (int rows = 0; rows < numOfRows; rows++) {

			// loop through column
			for (int cols = colIndex; cols == colIndex; cols++) {
				// check to make sure column exist for row
				if (twoDimRag[rows].length <= colIndex) {
					continue;
				}
				// if exists
				else {
					// find lowest value store its index location
					if (twoDimRag[rows][cols] < lowestInColumn) {
						lowestInColumn = twoDimRag[rows][cols];
						lowestInColumnIndex = rows;
					}
				}
			}
		}
		return lowestInColumnIndex;
	}
	
	public static double getHighestInArray(double[][] twoDimRag) {
		//declare double variable to store hgihest value in array
		double largestElement = -987654321;
		
		//get the number of rows in array
		int numOfRows = twoDimRag.length;
		
		//loop through rows
		for (int rows= 0; rows< numOfRows; rows++) {
			//get num of columns in that row
			int numOfCols = twoDimRag[rows].length;
			for (int cols = 0; cols < numOfCols; cols++) {
				//if element is bigger than largest element
				//make it the new largest element
				if (twoDimRag[rows][cols] > largestElement) {
					double newHighestElement = twoDimRag[rows][cols];
					largestElement = newHighestElement;
				}
			}
		}
		return largestElement;
	}
	
	public static double getLowestInArray(double[][] twoDimRag) {
		// declare double variable to store smallest value in array
		double smallestElement = 987654321;

		// get the number of rows in array
		int numOfRows = twoDimRag.length;

		// loop through rows
		for (int rows = 0; rows < numOfRows; rows++) {
			// get num of columns in that row
			int numOfCols = twoDimRag[rows].length;
			//loop through columns
			for (int cols = 0; cols < numOfCols; cols++) {
				//if element is smaller than smallest element, change it to new
				//smallest element
				if (twoDimRag[rows][cols] < smallestElement) {
					double newLowestElement = twoDimRag[rows][cols];
					smallestElement = newLowestElement;
				}
			}
		}
		return smallestElement;
	}
	
}












