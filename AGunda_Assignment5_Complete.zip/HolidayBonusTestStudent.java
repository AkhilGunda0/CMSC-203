import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class HolidayBonusTestStudent {
	private double[][] twoDimRag = {{10.1, 214.4, 1234}, {12.22, 12.1}, {-1,-50, -199.2}};
	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testCalculateHolidayBonus() {
		double[] result = HolidayBonus.calculateHolidayBonus(twoDimRag);
		assertEquals(12_000.0, result[0], .001);
		assertEquals(7_000.0, result[1], .001);
		assertEquals(0.0, result[2], .001);
	}

	@Test
	void testCalculateTotalHolidayBonus() {
		assertEquals(19000.0, HolidayBonus.calculateTotalHolidayBonus(twoDimRag), .0001);
	}

}
