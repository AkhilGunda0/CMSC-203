/*
 * Class: CMSC203 
 * Instructor: Dr. Tarek
 * Description: (Management Company class sets up a management 
 * company's plot of land, in which properties can be developed
 * property class adds property's in company's land
 * plot ensure that no properties overlap, and properties is within
 * company land)
 * Due: 10/24/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: ___Akhil Gunda_______
*/
public class Property {
	
	private String propertyName;
	private String city;
	private double rentAmount;
	private String owner;
	private Plot plot;
	
	//constructor 1 creates new empty property
	 public Property() {
		 propertyName = "";
		  city = "";
		  rentAmount = 0;
		    owner = "";
		    plot = new Plot();
		  }
	 //constructor 2 creates new property based on the values user provides
	 public Property(String propertyName, String city, double rentAmount, String owner) {
		 this.propertyName = propertyName;
			this.city = city;
			this.rentAmount = rentAmount;
			this.owner = owner;
			plot = new Plot();
	 }
	 //constructor 3 creates new property & plot based on values user provides
	 public Property(String propertyName, String city, double rentAmount, String owner, int x, int y, int width, int depth) {
		 this.propertyName = propertyName;
			this.city = city;
			this.rentAmount = rentAmount;
			this.owner = owner;
			this.plot = new Plot(x, y, width, depth);
	 }
	 // constructor 4 copies otherProperty to this property
	 public Property(Property otherProperty) {
		 plot = otherProperty.getPlot();
		 city = otherProperty.getCity();
		    owner = otherProperty.getOwner();
		    propertyName = otherProperty.getPropertyName();
		    rentAmount = otherProperty.getRentAmount();
	 }
	 
	

	 
	 //gets property name
	 public String getPropertyName() {
		 return propertyName;
	 }
	 //gets city name
	 public String getCity() {
		 return city;
	 }
	 //gets rent amount
	 public double getRentAmount() {
		 return rentAmount;
	 }
	 //gets owner name
	 public String getOwner() {
		 return owner;
	 }
	 //returns useful info as String about property
	 public String toString() {
		 String toString = ""+propertyName + "," + city + ","+ owner + ","+ rentAmount;
		 return toString;
	 }
	 
	 //sets plot 
	 public void setPlot(int x, int y, int width, int depth) {
		 this.plot = new Plot(x, y, width, depth);
	 }
	 
	 //sets property name;
	 public void setPropertyName(String propertyName2) {
		 propertyName = propertyName2;
	 }
	 //sets city name
	 public void setCity(String city2) {
		 city = city2;
	 }
	 //sets rent amount
	 public void setRentAmount(double rentAmount2) {
		 rentAmount = rentAmount2;
	 }
	 //sets owner name
	 public void setOwner(String owner2) {
		 owner = owner2;
	 }
	 
	 //gets plot
	  public Plot getPlot() {
		 return plot;
	 }
	 
	 
	 
}
