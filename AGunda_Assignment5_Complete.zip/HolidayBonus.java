/*
 * Class: CMSC203 
 * Instructor: Dr. Tarek
 * Description: Holiday Bonus calculates total holiday bonus for each store. It also calculates 
 * total bonus for all stores combined.  
 * Due: 11/14/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: __Akhil Gunda________
*/

public class HolidayBonus {
	private static final int HIGHEST_SALES_BONUS = 5000;
	private static final int LOWEST_SALES_BONUS = 1000;
	private static final int REGULAR_SALES_BONUS = 2000;
	
	//calculates holiday bonus amount for each store, stores it in array and returns it
	public static double[] calculateHolidayBonus(double[][] twoDimRag) {
		
		//the number of stores there are
		int numOfStores = twoDimRag.length;
		
		//declare the double variable that will store bonus amounts for each store
		double[] bonusAmount = new double[numOfStores];
		
		
		//this nested for loop adds the highest sales bonus
		//loop through stores (rows)
		for (int store = 0; store < numOfStores; store++) {
			
			//the number of items sold by each store
			int numOfItems = twoDimRag[store].length;
			
			//loop through items (columns)
			for (int item = 0; item <numOfItems; item++) {
				
				//find highest sold store for this particular item
				double highestSoldStore = TwoDimRaggedArrayUtility.getHighestInColumnIndex(twoDimRag, item);
				//find out how much the sales was
				double highestSoldStoreSales = TwoDimRaggedArrayUtility.getHighestInColumn(twoDimRag, item);
				//find lowest sold store for this particular item
				double lowestSoldStore = TwoDimRaggedArrayUtility.getLowestInColumnIndex(twoDimRag, item);
				//find out how much the sales was
				double lowestSoldStoreSales = TwoDimRaggedArrayUtility.getLowestInColumn(twoDimRag, item);
		
				//if stores match & sales are greater than 0, add HIGHEST_SALES_BONUS 
				if (store == highestSoldStore && highestSoldStoreSales > 0) {
					bonusAmount[store] += HIGHEST_SALES_BONUS;
				}
				//if stores match & sales are greater than 0, add LOWEST_SALES_BONUS
				else if (store == lowestSoldStore && lowestSoldStoreSales > 0) {
					bonusAmount[store] += LOWEST_SALES_BONUS;
				}
				//as long as sales are not less than or equal to zero add REGULAR_SALES_BONUS
				else if (twoDimRag[store][item] >= 0){
					bonusAmount[store] += REGULAR_SALES_BONUS;
				}
				//if sales are equal to or less than 0, the store does not get a bonus
				else {
					bonusAmount[store] += 0;
				}
			}
		}
		//return bonus amount for each store
		return bonusAmount;
	}
	
	//calculates total bonus amount for all stores combined
	public static double calculateTotalHolidayBonus(double[][] twoDimRag) {
		
		//the number of stores there are
		int numOfStores = twoDimRag.length;
		
		//declare the double variable that will store bonus amounts for each store
		double[] bonusAmount = new double[numOfStores];
		
		//initialize bonusAmount to zero to prevent initialization errors
		for (int i = 0; i < numOfStores; i++) {
			bonusAmount[i] = 0;
		}
		
		//this nested for loop adds the highest sales bonus
		//loop through stores (rows)
		for (int store = 0; store < numOfStores; store++) {
			
			//the number of items sold by each store
			int numOfItems = twoDimRag[store].length;
			
			//loop through items (columns)
			for (int item = 0; item <numOfItems; item++) {
				
				//find highest sold store for this particular item
				double highestSoldStore = TwoDimRaggedArrayUtility.getHighestInColumnIndex(twoDimRag, item);
				//find out how much the sales was
				double highestSoldStoreSales = TwoDimRaggedArrayUtility.getHighestInColumn(twoDimRag, item);
				//find lowest sold store for this particular item
				double lowestSoldStore = TwoDimRaggedArrayUtility.getLowestInColumnIndex(twoDimRag, item);
				//find out how much the sales was
				double lowestSoldStoreSales = TwoDimRaggedArrayUtility.getLowestInColumn(twoDimRag, item);
		
				//if stores match & sales are greater than 0, add HIGHEST_SALES_BONUS 
				if (store == highestSoldStore && highestSoldStoreSales > 0) {
					bonusAmount[store] += HIGHEST_SALES_BONUS;
				}
				//if stores match & sales are greater than 0, add LOWEST_SALES_BONUS
				else if (store == lowestSoldStore && lowestSoldStoreSales > 0) {
					bonusAmount[store] += LOWEST_SALES_BONUS;
				}
				//as long as sales are not less than or equal to zero add REGULAR_SALES_BONUS
				else if (twoDimRag[store][item] >= 0){
					bonusAmount[store] += REGULAR_SALES_BONUS;
				}
				//if sales are equal to or less than 0, the store does not get a bonus
				else {
					bonusAmount[store] += 0;
				}
			}
		}
		
		//declare double variable to store total bonus
		double totalBonus = 0;
		
		//enhanced for loop to add bonus amount of each store
		for (double temp: bonusAmount) {
			totalBonus += temp;
		}
		
		//return total bonus amount
		return totalBonus;
	}
}
