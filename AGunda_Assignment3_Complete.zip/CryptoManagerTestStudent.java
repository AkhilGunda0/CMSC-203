import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

public class CryptoManagerTestStudent {
	CryptoManager cryptoManager;

	@Test
	public void testStringInBounds() {
		assertTrue(CryptoManager.isStringInBounds("JAVA"));
	}

	@Test
	public void testEncryptCaesar() {
		assertEquals("#\\Y)&%7 *7^&X+\\[", CryptoManager.caesarEncryption("LEBRON IS GOATED", 23));
	}

	@Test
	public void testDecryptCaesar() {
		assertEquals("BATMOBILE IS FAST", CryptoManager.caesarDecryption("RQ$]_RY\\U0Y#0VQ#$", 16));
	}

	@Test
	public void testEncryptBellaso() {
		assertEquals("FPJV^%[&#I\\H^T_X", CryptoManager.bellasoEncryption("CHESS IS AWESOME", "CHECKERS"));
	}

	@Test
	public void testDecryptBellaso() {
		assertEquals("RICK RIORDAN IS A GREAT AUTHOR", CryptoManager.bellasoDecryption("XJYZ2[]T2EV\"(X%&B6V$NUY@B*(P^$", "FAVORITE AUTHOR"));
	}

}