/*
 * Class: CMSC203 
 * Instructor: Dr. Tarek
 * Description: TwoDimRaggedArrayUtilityTestStudent tests all the methods in the TwoDimRaggedArrayUtility.java file  
 * Due: 11/14/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: __Akhil Gunda________
*/

import static org.junit.jupiter.api.Assertions.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TwoDimRaggedArrayUtilityTestStudent {

	private double[][] twoDimRag = {{1,1}, {1,2,1}, {1,3,3,1}, {1,4,6,4,1}, 
			{1,5,10,10,5,1}};
	private File dataFile = new File("TwoDimRagUtilTest");
	
	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
		dataFile = null;
		twoDimRag = null;
	}

	@Test
	void testReadFile() throws FileNotFoundException {
		
		TwoDimRaggedArrayUtility.writeToFile(twoDimRag, dataFile);
		double[][]testingTwoDimRag = TwoDimRaggedArrayUtility.readFile(dataFile);
		assertEquals(twoDimRag[1][2], testingTwoDimRag[1][2], .001);
		assertEquals(twoDimRag[4][4], testingTwoDimRag[4][4], .001);
	}

	@Test
	void testWriteToFile() throws FileNotFoundException{
		
		TwoDimRaggedArrayUtility.writeToFile(twoDimRag, dataFile);
		double[][]testingTwoDimRag = TwoDimRaggedArrayUtility.readFile(dataFile);
		assertEquals(twoDimRag[3][2], testingTwoDimRag[3][2], .001);
		assertEquals(twoDimRag[0][1], testingTwoDimRag[0][1], .001);
	}

	@Test
	void testGetTotal() {
		assertEquals(62.0, TwoDimRaggedArrayUtility.getTotal(twoDimRag));
	}

	@Test
	void testGetAverage() {
		assertEquals(62.0/20, TwoDimRaggedArrayUtility.getAverage(twoDimRag));
	}

	@Test
	void testGetRowTotal() {
		assertEquals(2.0,TwoDimRaggedArrayUtility.getRowTotal(twoDimRag, 0));
	}

	@Test
	void testGetColumnTotal() {
		assertEquals(5.0,TwoDimRaggedArrayUtility.getColumnTotal(twoDimRag, 0));
	}

	@Test
	void testGetHighestInRow() {
		assertEquals(10.0,TwoDimRaggedArrayUtility.getHighestInRow(twoDimRag, 4));
	}

	@Test
	void testGetHighestInRowIndex() {
		assertEquals(2.0,TwoDimRaggedArrayUtility.getHighestInRowIndex(twoDimRag, 4));
	}

	@Test
	void testGetLowestInRow() {
		assertEquals(1.0,TwoDimRaggedArrayUtility.getLowestInRow(twoDimRag, 4));
	}

	@Test
	void testGetLowestInRowIndex() {
		assertEquals(1.0,TwoDimRaggedArrayUtility.getLowestInRow(twoDimRag, 4));
	}

	@Test
	void testGetHighestInColumn() {
		assertEquals(5.0,TwoDimRaggedArrayUtility.getHighestInColumn(twoDimRag, 1));
	}

	@Test
	void testGetHighestInColumnIndex() {
		assertEquals(4.0,TwoDimRaggedArrayUtility.getHighestInColumnIndex(twoDimRag, 1));
	}

	@Test
	void testGetLowestInColumn() {
		assertEquals(1.0,TwoDimRaggedArrayUtility.getLowestInColumn(twoDimRag, 3));
	}

	@Test
	void testGetLowestInColumnIndex() {
		assertEquals(2.0,TwoDimRaggedArrayUtility.getLowestInColumnIndex(twoDimRag, 3));
	}

	@Test
	void testGetHighestInArray() {
		assertEquals(10.0,TwoDimRaggedArrayUtility.getHighestInArray(twoDimRag));
	}

	@Test
	void testGetLowestInArray() {
		assertEquals(1.0,TwoDimRaggedArrayUtility.getLowestInArray(twoDimRag));
	}

}
