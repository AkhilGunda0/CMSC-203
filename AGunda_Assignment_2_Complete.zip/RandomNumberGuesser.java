/*
 * Class: CMSC203 
 * CRN:21078
 * Instructor: Ahmed Tarek
 * Description: randomNumberGuesser will generate random number and ask user to guess it. Maximum tries user gets is 7.
 * Due: 9/26/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: __Akhil Gunda______
*/

import java.util.Scanner;

/* this class will generate random number and ask user to guess it. Maximum tries user gets is 7. It has two methods.*/
public class RandomNumberGuesser 
{
	//this method will generate random number and let user guess. will call tryAgain method when game ends.
	public static void main(String args[])
	{
		//string that is used to determine whether or not to play program again
		String tryAgainStr ="";
		
		do {
			
			//declare and initialize variables used in the program
			int lowGuess = 1, highGuess = 100;
			int count = 0;
			
			//Inform user of the purpose of this application
			System.out.println("This application generates a random integer between 1 and 100 "
					+ "and asks the user to guess repeatedly until they guess correctly.\n");
			//create integer random to store the random number generated
			int random;
			
			//create a random number and store it in random variable
			random = RNG.rand();
			
			//create scanner object to read user input
			Scanner keyboard = new Scanner(System.in);
			
			//loop to run 7 times
			for(int i=0; i<7; i++)
			{
				
				//ask user to guess the random number
				if (RNG.getCount() == 0)
				{
					System.out.println("Enter your first guess between " + lowGuess  + " and " + highGuess + ": ");
				}
				else 
				{
					System.out.println("Enter your next guess between " + lowGuess + " and " + highGuess + ": ");
				}
				
				//create variable to read user input
				int nextGuess;
				
				//read user input using scanner object
				nextGuess = keyboard.nextInt();
				
				//make sure user entered value is in range
				while (!(RNG.inputValidation(nextGuess, lowGuess, highGuess)))
				{
					nextGuess = keyboard.nextInt();
					count--;
				}
				//inform user guess smaller than actual random number
				if (nextGuess < random)
				{
					System.out.println("Your guess is too low");
					lowGuess = nextGuess;
					
					//if 7 guesses made, end game play and revel correct answer. Ask user if he/she wants to play again. 
					if ((RNG.getCount() + count) == 7)
					{
						System.out.println("You have exceeded the maximum number of guesses, " + (RNG.getCount() + count));
						System.out.println("The correct answer was " + random);
						tryAgainStr = tryAgain();
					}
					else
					{
						System.out.println("Number of guesses is: " + (RNG.getCount() + count));
					}
				}
				//inform user guess is larger than actual random number
				else if (nextGuess > random)
				{
					System.out.println("Your guess is too high");
					highGuess = nextGuess;
					
					//if 7 guesses made, end game play and revel correct answer. Ask user if he/she wants to play again. 
					if ((RNG.getCount() + count) == 7)
					{
						System.out.println("You have exceeded the maximum number of guesses, " +(RNG.getCount() + count));
						System.out.println("The correct answer was " + random);
						tryAgainStr = tryAgain();
					}
					else
					{
						System.out.println("Number of guesses is: " + (RNG.getCount() + count));
					}
				}
				//congratulate user for guessing the random number correctly
				else if (nextGuess == random)
				{
					System.out.println("Congratulations, you guessed correctly");
					tryAgainStr = tryAgain();
				}
			}
			
			
			
		}
		while("yes".equalsIgnoreCase(tryAgainStr));
	}
	
	//this method will ask user if he wants to play the game again
	public static String tryAgain()
	{
		//create scanner object to read user input
		Scanner keyboard = new Scanner(System.in);
				
		//ask user if he/she wants to play game again
		System.out.println("Try again? (yes or no)");
		
		//initialize tryAgain to null
		String tryAgain = null;
		
		//read user input
		tryAgain = keyboard.next();
		
		//if user didn't enter yes or no, prompt user to enter yes or no
		while (!(tryAgain.equalsIgnoreCase("yes")) && !(tryAgain.equalsIgnoreCase("no")))
		{
			System.out.println("Please enter yes or no: ");
			tryAgain = keyboard.next();
		}
		
		//if user enters yes, resent counter
		if ((tryAgain.equalsIgnoreCase("yes")))
				{
					RNG.resetCount();
				}
		//if user enters no, thank user for playing and display programmer name
		else if ((tryAgain.equalsIgnoreCase("no")))
		{
			System.out.println("Thanks for playing...");
			System.out.println("Programmer Name: Akhil Gunda");
			System.exit(0);
		}
		//by returning tryAgain, the do while loop will know to run another iteration
		return tryAgain;
	}
}
