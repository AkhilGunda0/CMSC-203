/*
 * Class: CMSC203 
 * Instructor: Dr. Tarek
 * Description: gets useful data from an order
 * Due: 12/5/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: __Akhil Gunda________
*/

import java.util.*;

public class Order implements OrderInterface, Comparable {
	private int orderNumber;
	private int orderTime;
	private DAY orderDay;
	private Customer cust;
	private ArrayList<Beverage> beverages  = new ArrayList<>();
	
	//constructor sets the fields
	public Order(int orderTime, DAY orderDay, Customer cust) {
		this.orderTime = orderTime;
		this.orderDay = orderDay;
		this.cust = cust;
	}
	
	//generates order number
	public int generateOrder() {
		Random rand = new Random();
		int orderNumber = rand.nextInt(80_000) + 10_000;
		return orderNumber;
	}
	
	//returns order number
	public int getOrderNo() {
		return orderNumber;
	}
	
	//returns order time
	public int getOrderTime() {
		return orderTime;
	}
	
	//gets order date
	public DAY getOrderDay() {
		return orderDay;
	}
	
	//returns a deep copy of customer
	public Customer getCustomer() {
		return new Customer(cust);
	}
	
	//returns order day
	public DAY getDay() {
		return orderDay;
	}
	
	//checks if is weekend or not
	public boolean isWeekend() {
		if (this.orderDay.equals(DAY.SATURDAY) || this.orderDay.equals(DAY.SUNDAY)) {
			return true;
		} else {
			return false;
		}
	}
	
	//returns beverage at x index location
	public Beverage getBeverage(int itemNo) {
		return beverages.get(itemNo);
	}
	
	//returns beverage list
	public ArrayList<Beverage> getBeverages() {
	       return beverages;
	}
	 
	//returns the total number of beverages ordered
	public int getTotalItems() {
		return beverages.size();
	}
	
	//create a new coffee beverage and then adds it to array list
	public void addNewBeverage(String bevName, SIZE size, boolean extraShot, boolean extraSyrup) {
		//create new coffee object
		Coffee coffee = new Coffee(bevName, size, extraShot, extraSyrup);
		//add new coffee object to arraylist
		beverages.add(coffee);
	}
	
	//create a new alcohol beverage and then adds it to array list
	public void addNewBeverage(String bevName, SIZE size) {
		//create new alchol object
		Alcohol alcohol = new Alcohol(bevName, size, isWeekend());
		//add the new alcohol object to arraylist
		beverages.add(alcohol);
	}

	//creates a new smoothie beverage and then adds it to the array list
	public void addNewBeverage(String bevName, SIZE size, int numOfFruits, boolean addProtein) {
		//create new smoothie
		Smoothie smoothie = new Smoothie(bevName, size, numOfFruits, addProtein);
		//add smoothie to arraylist
		beverages.add(smoothie);
	}
	
	//calculate the total price of order
	public double calcOrderTotal() {
		int numOfBeverages = beverages.size();
		double orderTotal = 0d;
		
		//get price for each item, and add it to total
		for (double beverage = 0; beverage < numOfBeverages; beverage++) {
			orderTotal += beverages.get((int) beverage).calcPrice();
		}
		return orderTotal;
	}
	
	//finds the number of either coffee, smoothie, or alchol
	public int findNumOfBeveType(TYPE randomBevType) {
		int numOfBeverages = beverages.size();
		double xtypes = 0d;
		
		//loop through arraylist of beverages, check if same type, if same type add 1 to counter variable
		for (int beverage = 0; beverage < numOfBeverages; beverage++) {
			
			if (beverages.get(beverage).getType().equals(randomBevType)) {
				xtypes = xtypes + 1;
			}
			else {
				xtypes += 0;
			}
		}
		return (int) xtypes;
	}
	
	//returns order, and beverages info
	public String toString() {
		 String part1 = "Order Number: " + this.orderNumber + "\n Order time: " + this.orderTime + "\n Order day: "
					+ this.orderDay + ""
							+ "\n Customer name: " + cust.getName() + "\n Age: " + cust.getAge() + "\n Beverages: ";
		 
		 String part2 ="";
		 for (int i = 0; i <beverages.size(); i++) {
			 part2 += beverages.get(i).toString();
		 }
		 return part1 + part2 + "\n Order Total: " + calcOrderTotal();
	}
	
	//returns 0 if order numbers of two orders are the same
	//returns 1 if this order number is greater than other order number
	//return -2 if this order number is smaller than other order number
	public int compareTo(Order anotherOrder) {
		int anotherOrderNumber = anotherOrder.getOrderNo();
		
		if (anotherOrderNumber == this.orderNumber) {
			return 0;
		}
		else if (anotherOrderNumber > this.orderNumber) {
			return -1;
		}
		else if (this.orderNumber > anotherOrderNumber) {
			return 1;
		}
		//error
		else {
			System.out.println("compareTo method, Order class, something is wrong");
			return -9999;
		}
	}

	@Override
	public int compareTo(Object o) {
		int anotherOrderNumber = ((Order) o).getOrderNo();
		
		if (anotherOrderNumber == this.orderNumber) {
			return 0;
		}
		else if (anotherOrderNumber > this.orderNumber) {
			return -1;
		}
		else if (this.orderNumber > anotherOrderNumber) {
			return 1;
		}
		//error
		else {
			System.out.println("compareTo method, Order class, something is wrong");
			return -9999;
		}
	}
}






























