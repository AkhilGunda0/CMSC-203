/*
 * Class: CMSC203 
 * Instructor: Dr. Tarek
 * Description: creates consumer object with name and age
 * Due: 12/5/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: __Akhil Gunda________
*/

public class Customer {
	private int age;
	private String name;
	
	//copy constructor
	Customer(Customer c){
		this.age = c.age;
		this.name = c.name;
	}
	
	//constructor that copies fields
	Customer(String name, int age){
		this.age = age;
		this.name = name;
	}
	
	//returns age
	public int getAge() {
		return age;
	}
	
	//sets age
	public void setAge(int age) {
		this.age = age;
	}
	
	//returns name
	public String getName() {
		return name;
	}
	
	//sets name
	public void setName(String name) {
		this.name = name;
	}
	
	//return customer name and age
	public String toString() {
		return "Customer Name: " + this.name + " Age: " + this.age;
	}
}
