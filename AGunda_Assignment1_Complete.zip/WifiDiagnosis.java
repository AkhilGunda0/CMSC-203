
/*
 * Class: CMSC203 
 * Instructor: Ahmed Tarek
 * Description: (Give a brief description for each Class) Main runs the programmer through wifi diagnosis
 * 														 to figure out why Internt is not working
 * Due: 9/12/2021
 * Platform/compiler: Eclipse 2018
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: _Akhil Gunda________
*/

import  java.util.Scanner; // import Scanner library

/**
 * Date: 9/12/2022
 * This is a program that walks the user though wifi diagnosis to figure out why their internet is not working. 
 * @author Akhil Gunda
 * @version 1.0
 */
public class WifiDiagnosis
{
	/**
	 * The main method of this application walks the user through Internet diagnosis. 
	 * @param args array of string arguments
	 */
	public static void main (String[] args)
	{
		// declare scanner object to read input from user
		Scanner userInput = new Scanner(System.in);
		
		//How to Wifi Diagnosis
		System.out.println("If you have a problem with internet connectivity, this WiFi Diagnosis might work.\n");
		//First Step: Reboot computer
		System.out.println("First step: reboot your computer");
		//Check if Internet connection is working
		System.out.println("Are you able to connect with the internet? (yes or no)");
		
		// declare variable router to store user input
		String computer;
		computer = userInput.next();
		
		//if Rebooting fixes Internet
		if ("yes".equals(computer))
		{
			System.out.println("Rebooting your computer seemed to work");
			System.out.println("Programmer Name: Akhil Gunda");
			//to exit program
			System.exit(0);
		}
		//if not, second step reboot router
		else if ("no".equals(computer)) 
		{
			//second step: rebooting router
			System.out.println("Second step: reboot your router\n" 
								+ "Now are you able to connect with the internet? (yes or no)");
			// declare variable router to store user input
			String router;
			router = userInput.next();
			
			//if rebooting router works
			if ("yes".equals(router))
			{
				System.out.println("Rebooting your router seemed to work");
				System.out.println("Programmer Name: Akhil Gunda");
				System.exit(0);
			}
			//if rebooting router doesn't work, step 3: making sure router is receiving power
			else if ("no".equals(router))
			{
				System.out.println("Third step: make sure the cables to your router are plugged in firmly and your router is getting power");
				System.out.println("Now are you able to connect with the internet? (yes or no)");
				
				// to read user input
				String power;
				power = userInput.next();
				
				//if fixing router cables worked
				if ("yes".equals(power))
				{
					System.out.println("Checking the router's cables seemed to work");
					System.out.println("Programmer Name: Akhil Gunda");
					System.exit(0);
				}
				//if fixing router cables didn't fix wifi issue, Fourth step: make sure ur in range to internet
				else if ("no".equals(power))
				{
					System.out.println("Fourth step: move your computer closer to your router\n" 
							+ "Now are you able to connect with the internet? (yes or no)");
					
					//to read user input
					String distance;
					distance = userInput.next();
					
					// if coming closer to the internet worked
					if ("yes".equals(distance))
					{
						System.out.println("Coming closer to the router seemed to work");
						System.out.println("Programmer Name: Akhil Gunda");
						System.exit(0);
					}
					//if coming closer to the internet did not work. Final step contact ISP. 
					else if ("no".equals(distance))
					{
						System.out.println("Fifth step: contact your ISP\n" + 
								"Make sure your ISP is hooked up to your router.\n");
						System.out.println("Programmer Name: Akhil Gunda");
						System.exit(0);
					}
					
				}
			}
			
		}
		
	}

}
