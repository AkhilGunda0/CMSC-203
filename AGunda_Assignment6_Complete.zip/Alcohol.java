/*
 * Class: CMSC203 
 * Instructor: Dr. Tarek
 * Description: Creates Alcohol beverage type, extends Beverage class
 * Due: 12/5/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: __Akhil Gunda________
*/

public class Alcohol extends Beverage{
	private boolean isOffered;
	private final double ALCOHOLCOST = .6;
	
	//constructor create alcohol object and stores whether is offered
	public Alcohol(String bevName, SIZE size, boolean isWeekend) {
		super(bevName, TYPE.ALCOHOL, size);
		this.isOffered = isWeekend;
	}
	
	//return beverage alchol info
	public String toString() {
		return "Beverage Name:" + this.beverageName + ", Size:" + getSize() +
				"alcholic drinks offered: "+ this.isOffered + 
				", Total Price: " + calcPrice();
	}
	
	//checks if two alchol beverages are the same
	public boolean equals(Object anotherBev) {
		if (this.beverageName.equals(((Beverage) anotherBev).getBevName())
				&& this.getType().equals(((Beverage) anotherBev).getType()) 
				&& this.getSize().equals(((Beverage) anotherBev).getSize())) {
			
			if(this.isOffered == ((Alcohol) anotherBev).isOffered)
			{
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	
	//calculates price of alchol drink
	public double calcPrice() {
		// declare double variable to store price
		double alcoholPrice = 0;
		// get the size of coffee by calling inherited method from Beverage
		SIZE tempSize = getSize();

		// add appropriate price to coffee based on size
		if (tempSize == SIZE.SMALL) {
			
			alcoholPrice = 2;
			if (isOffered == true) {
				alcoholPrice += ALCOHOLCOST;
			}

		} else if (tempSize == SIZE.MEDIUM) {
			alcoholPrice = 3;
			if (isOffered == true) {
				alcoholPrice += ALCOHOLCOST;
			}
		} else if (tempSize == SIZE.LARGE) {
			alcoholPrice = 4;

			if (isOffered == true) {
				alcoholPrice += ALCOHOLCOST;
			}

		} else {
			System.out.println("SOMETHING WENT WRONG COFFEE.JAVA");
			System.exit(-1);
		}
		return alcoholPrice;
	}
	
	//returns if alchol is offered or not
	public boolean isWeekend() {
		return isOffered;
	}
	
}
