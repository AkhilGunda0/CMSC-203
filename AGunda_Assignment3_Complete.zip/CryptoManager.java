/*
 * Class: CMSC203 
 * Instructor: Ahmed Tarek
 * Description: (crypto manager class does ceaser and bellaso encripting and decrypting. 
 * cryptomanagerstudentTest runs junit tests to make sure every method in crytoManager works.)
 * Due: 10/10/22
 * Platform/compiler: eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: ____Akhil Gunda______
*/

/**
 * This is a utility class that encrypts and decrypts a phrase using two
 * different approaches. The first approach is called the Caesar Cipher and is a
 * simple “substitution cipher” where characters in a message are replaced by a
 * substitute character. The second approach, due to Giovan Battista Bellaso,
 * uses a key word, where each character in the word specifies the offset for
 * the corresponding character in the message, with the key word wrapping around
 * as needed.
 * 
 * @author Farnaz Eivazi
 * @version 7/16/2022
 */
public class CryptoManager {
	
	private static final char LOWER_RANGE = ' ';
	private static final char UPPER_RANGE = '_';
	private static final int RANGE = UPPER_RANGE - LOWER_RANGE + 1;

	/**
	 * This method determines if a string is within the allowable bounds of ASCII codes 
	 * according to the LOWER_RANGE and UPPER_RANGE characters
	 * @param plainText a string to be encrypted, if it is within the allowable bounds
	 * @return true if all characters are within the allowable bounds, false if any character is outside
	 */
	public static boolean isStringInBounds (String plainText) {
		
		//declare string length variable to store length of string
		int stringLength = plainText.length();
		
		//we are using a for loop because we know exactly how many times the loop will run
		for (int i = 0; i <stringLength; i++)
		{
			//the if statement checks if plaintext is not within ranger, if it is not within range, it returns false
			if (!(plainText.charAt(i) >= LOWER_RANGE && plainText.charAt(i) <= UPPER_RANGE))
			{
				return false;
			}
		}
		//if every element is within range, it returns true
		return true;
	}

	/**
	 * Encrypts a string according to the Caesar Cipher.  The integer key specifies an offset
	 * and each character in plainText is replaced by the character \"offset\" away from it 
	 * @param plainText an uppercase string to be encrypted.
	 * @param key an integer that specifies the offset of each character
	 * @return the encrypted string
	 */
	public static String caesarEncryption(String plainText, int key) {
		
		//declare necessary variables
		boolean inBounds = CryptoManager.isStringInBounds(plainText);
		int stringLength = plainText.length();
		char[] encryptedArray = new char[stringLength];
		char[] plainTextArray = new char[stringLength];
		int inRangeKey = key;
		
		//make sure entered text is inbounds
		if (!inBounds)
		{
			
			return "The selected string is not in bounds, Try again.";
		}
		
		//change key to allowable range
		if (key>64)
		{
			inRangeKey = (key %= 64);
		}
		
		//make plaintext an array so we can work with it 
		for (int i= 0; i< stringLength; i++)
		{
			plainTextArray[i] = plainText.charAt(i);
		}
		
		//add the key to plain text array to get encrypted array
		for(int i = 0; i < stringLength; i++) {
			
			encryptedArray[i] =   (char) (plainTextArray[i] + (char)(inRangeKey));
		}
		
		//make sure ecrypted array is within allowable range
		for (int i =0; i < stringLength; i++)
			{
			
			if(encryptedArray[i] > UPPER_RANGE) {
				
				encryptedArray[i] = (char) (encryptedArray[i] - 64);
			}
			
		}
		//declare new string object to store encryptedarray and return it
			String encryptedString = new String(encryptedArray);
			return encryptedString;
	}
	
	/**
	 * Encrypts a string according the Bellaso Cipher.  Each character in plainText is offset 
	 * according to the ASCII value of the corresponding character in bellasoStr, which is repeated
	 * to correspond to the length of plainText
	 * @param plainText an uppercase string to be encrypted.
	 * @param bellasoStr an uppercase string that specifies the offsets, character by character.
	 * @return the encrypted string
	 */
	public static String bellasoEncryption (String plainText, String bellasoStr) {
		
// declare necessary variables
		int stringLength = plainText.length();
		int keyLength = bellasoStr.length();
		
		char[] bellasoKey = new char[stringLength];
		char[] encryptedArray = new char[stringLength];
		char[] plainTextArray = new char[stringLength];
		
		// for loop to store plaintext in an array
		for(int i =0; i < stringLength; i++)
		{
			plainTextArray[i] = plainText.charAt(i);
		}
		
		//for loop to create an array of the key
		for (int i=0; i< stringLength; i++)
		{
			bellasoKey[i] = bellasoStr.charAt(i % keyLength);
		}
		
		//add key to plaintext array to encrypt it 
		for (int i=0; i<stringLength; i++)
		{
			encryptedArray[i] = (char) (plainTextArray[i] + bellasoKey[i]);	
		}
		
		//make sure encrypted array is not greater than the upper range
		for (int i = 0; i < stringLength; i++)
		{
			while (encryptedArray[i] > UPPER_RANGE)
			{
				encryptedArray[i] = (char) (encryptedArray[i] - 64);
			}
		}
		//declare new string store the encrypted array in it and return it
		String encryptedString = new String(encryptedArray);
		return encryptedString;
	}
	    
	/**
	 * Decrypts a string according to the Caesar Cipher.  The integer key specifies an offset
	 * and each character in encryptedText is replaced by the character \"offset\" characters before it.
	 * This is the inverse of the encryptCaesar method.
	 * @param encryptedText an encrypted string to be decrypted.
	 * @param key an integer that specifies the offset of each character
	 * @return the plain text string
	 */
	public static String caesarDecryption (String encryptedText, int key) {
		//declare necessary data types
		int stringLength = encryptedText.length();
		char[] decryptedArray = new char[stringLength];
		char[] decryptedTextArray = new char[stringLength];
		int inRangeKey = key;
		
		//make sure key is in range
		if (key>64)
		{
			inRangeKey = (key %= 64);
		}
		
		//store encrypted text in decrypted test array that will soon be decrypted. 
		for (int i= 0; i< stringLength; i++)
		{
			decryptedTextArray[i] = encryptedText.charAt(i);
		}
		
		//by adding the key, decrypt the decrypted array
		for(int i = 0; i < stringLength; i++) {
			
			decryptedArray[i] =   (char) (decryptedTextArray[i] - (char)(inRangeKey));
		}
		//make sure the decrypted array is not lower than the lower range. 
		for (int i =0; i < stringLength; i++)
		{
			// if it is lower than the lower range, wrap it around 1 full circle of range
				if(decryptedArray[i] < LOWER_RANGE) {
				
				decryptedArray[i] = (char) (64 + decryptedArray[i]);
				}
		}
		//declare new string to store decrypted array in. then return the decrypted array. 
		String decryptedString = new String(decryptedArray);
		return decryptedString;
		
		
	}
	
	/**
	 * Decrypts a string according the Bellaso Cipher.  Each character in encryptedText is replaced by
	 * the character corresponding to the character in bellasoStr, which is repeated
	 * to correspond to the length of plainText.  This is the inverse of the encryptBellaso method.
	 * @param encryptedText an uppercase string to be encrypted.
	 * @param bellasoStr an uppercase string that specifies the offsets, character by character.
	 * @return the decrypted string
	 */
	public static String bellasoDecryption(String encryptedText, String bellasoStr) {
// declare the necessary primites data types and arrays, and string
		String decryptedString = "";
		int stringLength = encryptedText.length();
		int keyLength = bellasoStr.length();
		char[] bellasoKey = new char[stringLength];
		
		//elongate the length of the key and fit it in an array
		for (int i=0; i< stringLength; i++)
		{
			bellasoKey[i] = bellasoStr.charAt(i % keyLength);
		}
		
		
		for (int i = 0; i < stringLength; i++)
		{
			//change encrypted text to a int
			int encryptedChar = encryptedText.charAt(i);
			//decrypted the encrypted text by subtracting key
			int decryptedChar = (int)(encryptedChar) - (int)(bellasoKey[i]);
			//if the decrypted char is lower than lower range, add a full cycle of range to it
			// in essence you are are wrapping the chars in the range
			while (decryptedChar < LOWER_RANGE)
			{
				decryptedChar += 64;
			}
			//add the decrypted chars together to make a string
			decryptedString = decryptedString + (char)decryptedChar;
		}
		//return the decrypted string. 
		return decryptedString;
	}
	}
