/*
 * Class: CMSC203 
 * Instructor: Dr. Tarek
 * Description: (Management Company class sets up a management 
 * company's plot of land, in which properties can be developed
 * property class adds property's in company's land
 * plot ensure that no properties overlap, and properties is within
 * company land)
 * Due: 10/24/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: ___Akhil Gunda_______
*/

import javafx.scene.Scene;

public class ManagementCompany {
	
	public static void main(String[] args) {
		ManagementCompany mc= new ManagementCompany("Railey", "555555555",6);
		System.out.println("Begin");
		System.out.println(mc.toString());
		System.out.println("End");
	}
	//required attributes
	private String ManagementCompanyName;
	private String TaxID;
	private double managementFeePercentage;
	
	//consts attributes
	public static final int MAX_PROPERTY = 5;
	public static final int MGMT_WIDTH =10;
	public static final int MGMT_DEPTH = 10;
	
	//other attributes
	private Property[] properties;
	private Plot plot;
	private int numberOfProperties;
	private int propertyCount;
	
	//constructor 1: management company with empty string, default plot, and initializes properties array
	public ManagementCompany() {
		ManagementCompanyName = "";
		TaxID = "";
		managementFeePercentage = 0;
		plot = new Plot(0, 0, MGMT_WIDTH, MGMT_DEPTH);
		properties = new Property[MAX_PROPERTY];
	}
	
	//constructor 2: creates a management company object, creates a default plot, initializes properties array
	public ManagementCompany(String name, String taxID, double mgmFee) {
		ManagementCompanyName = name;
		TaxID = taxID;
		managementFeePercentage = mgmFee;
		plot = new Plot(0, 0, MGMT_WIDTH, MGMT_DEPTH);
		properties = new Property[MAX_PROPERTY];
	}
	
	//constructor 3: creates ManagementCompany object, creates plot, initialzies property array
	public ManagementCompany(String name, String taxID, double mgmFee, int x, int y, int width, int depth) {
		ManagementCompanyName = name;
		TaxID = taxID;
		managementFeePercentage = mgmFee;
		plot = new Plot(x, y, width, depth);
		properties = new Property[MAX_PROPERTY];
	}
	
	//constructor 4: creates a copy of ManagementCompany
	ManagementCompany(ManagementCompany otherCompany) {
		ManagementCompanyName = otherCompany.ManagementCompanyName;
		TaxID = otherCompany.TaxID;
		managementFeePercentage = otherCompany.managementFeePercentage;
		plot = otherCompany.plot;
		properties = otherCompany.properties;
		propertyCount = otherCompany.propertyCount;
	}
	
	//get company name
	public String getName() {
		return ManagementCompanyName;
	}
	//set company name
	public void setManagementCompanyName(String companyName) {
		ManagementCompanyName = companyName;
	}
	//get taxID
	public String getTaxID() {
		return TaxID;
	}
	
	//set taxID
	public void setTaxID(String taxID) {
		TaxID = taxID;
	}
	
	//get managementFeePercentage
	public double getManagementFeePercentage() {
		return this.managementFeePercentage;
	}
	
	//set managementFeePercentage
	public void setManagementFeePercentage(double feepercent) {
		managementFeePercentage = feepercent;
	}
	
	//Adds a new property if it qualifies
	public int addProperty(Property property) {
		//checks to see not more than 5 properties
		if (propertyCount == 5) {
			return -1;
		}
		//checks to make sure property is not null
		else if (property == null) {
			return -2;
		}
		//checks to see property is encompassed by management company plot
		Plot pp = property.getPlot();
		if (!(plot.encompasses(pp))){
			return -3;
		}
		//checks to see property does not overlap any of the other properties of company
		for (int i = 0; i < propertyCount; i++) {
			if (properties[i].getPlot().overlaps(property.getPlot())) {
				return -4;
			}
		}
		//if passes all conditions, adds new property
		properties[propertyCount] =new Property(property);
		propertyCount++;
		//returns index of array where the new property was added
		return propertyCount - 1;
	}
	// calls the addProperty Method above. the same thing will be returned as above method
	 public int addProperty(String propertyName, String city, double rent, String ownerName) {
		 //create new property so we can call above method
		 Property ppp = new Property (propertyName, city, rent, ownerName);
		 //call the method above
		   return addProperty(ppp);
	 }
	 //calls the addProperty method 2 methods above. the same thing will be returned as that method
	 public int addProperty(String propertyName, String city, double rent, String ownerName, int x, int y, int width, int depth) {
		//create new property so we can call method  
		 Property pppp = new Property(propertyName, city, rent, ownerName, x, y, width, depth);
		//call method
		 return addProperty(pppp);
     }
	 
	 //returns total rent all properties earn
	 public double getTotalRent() {
		double totalRent = 0;
		//add rents of every property
		for(int i = 0; i < propertyCount; i++) {
			totalRent += properties[i].getRentAmount();
		}
		return totalRent;
	 }
	 
	 //get highest rent property
	 public Property getHighestRentPropperty() {
		 int property = 0;
		 double maxRent = 0;
		 for (int i = 0; i < propertyCount; i++) {
			 if(properties[i].getRentAmount() > maxRent) {
					maxRent = properties[i].getRentAmount();
					property = i;
				}
		 }
		 return properties[property];
	 }
	//removes last property by nullifying it	
	 public void removeLastProperty() {
		 properties[propertyCount]= null;
	 }
	 //checks if properties is full
	 public boolean isPropertiesFull() {
		 if (propertyCount ==5)
			 return true;
		 else 
			 return false;
	 }
	//gets Properties Count
	public int getPropertiesCount() {
		return propertyCount;
	}
	//checks to see if management fee is between 0 and 100
	public boolean isManagementFeeValid() {
		if (managementFeePercentage >= 0.0 && managementFeePercentage <= 100.0) {
			return true;
		}
		else
			return false;
	}
	
	//returns info about all properties
	public String toString() {
		String CompanyName_TaxID = "List of properties for " + ManagementCompanyName + ", taxID: " + TaxID 
				+"\n______________________________________________________\n";
		
		String properties2 = "";
		 for (int i = 0; i < propertyCount; i++) {
		      properties2 += this.properties[i] + "\n"; 
		    }
		 
		double totalRent = getTotalRent();
		double totalManagementFee = totalRent * managementFeePercentage / 100;
			
			String fee = "______________________________________________________\n" + "Total Management Fee: " + totalManagementFee;
		
		String toString = CompanyName_TaxID + properties2 + fee;
		
		return toString;
	}

	//gets plot
	public Plot getPlot() {
		return this.plot;
	}
	//gets max property
	public int getMAX_PROPERTY() {
		return this.MAX_PROPERTY;
	}

	
}
























