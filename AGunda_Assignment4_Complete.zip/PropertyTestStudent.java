/*
 * Class: CMSC203 
 * Instructor: Dr. Tarek
 * Description: (Management Company class sets up a management 
 * company's plot of land, in which properties can be developed
 * property class adds property's in company's land
 * plot ensure that no properties overlap, and properties is within
 * company land)
 * Due: 10/24/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: ___Akhil Gunda_______
*/
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PropertyTestStudent {

	Property prop1, prop2, prop3;
	
	@BeforeEach
	void setUp() throws Exception {
		prop1 = new Property("TripleP", "Jamestown", 3000.00, "James");
		prop2 = new Property();
		prop3 = new Property("DarkPalace", "Underground", 0.99, "Witch");
		
	}

	@AfterEach
	void tearDown() throws Exception {
		prop1 = prop2 = prop3 = null;
	}

	@Test
	void testGetPropertyName() {
		prop2.setPropertyName("Apollo");
		assertEquals("Apollo", prop2.getPropertyName());
	}

	@Test
	void testGetCity() {
		assertEquals("Underground", prop3.getCity());
	}

	@Test
	void testGetRentAmount() {
		assertEquals(.99, prop3.getRentAmount());
	}

	@Test
	void testGetOwner() {
		assertEquals("Witch", prop3.getOwner());
	}

	@Test
	void testToString() {
		assertEquals("DarkPalace,Underground,Witch,0.99",prop3.toString());	
	}

	@Test
	void testSetPlot() {
		prop2.setPlot(9, 9, 1, 1);
		assertEquals("9,9,1,1",prop2.getPlot().toString());
	}

	@Test
	void testSetPropertyName() {
		prop2.setPropertyName("WhiteCastle");
		assertEquals("WhiteCastle",prop2.getPropertyName());
	}

	@Test
	void testSetCity() {
		prop2.setCity("MountOlympus");
		assertEquals("MountOlympus",prop2.getCity());
	}

	@Test
	void testSetRentAmount() {
		prop2.setRentAmount(10_000_000);
		assertEquals(10_000_000,prop2.getRentAmount());
	}

	@Test
	void testSetOwner() {
		prop2.setOwner("Zeus");
		assertEquals("Zeus",prop2.getOwner());
	}

	@Test
	void testGetPlot() {
		prop2.setPlot(9, 9, 1, 1);
		assertEquals("9,9,1,1",prop2.getPlot().toString());
	}

}
