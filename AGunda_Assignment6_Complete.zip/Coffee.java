/*
 * Class: CMSC203 
 * Instructor: Dr. Tarek
 * Description: Creates coffee beverage type, extends Beverage class
 * Due: 12/5/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: __Akhil Gunda________
*/

public class Coffee extends Beverage {
	
	public boolean extraShotOfCoffee;
	public boolean extraShotOfSyrup;

	//constructor creates beverage and stores Coffee fields
	public Coffee(String bevName, SIZE size, boolean extraShot, boolean extraSyrup) {
		super(bevName, TYPE.COFFEE, size);
		extraShotOfCoffee = extraShot;
		extraShotOfSyrup = extraSyrup;
	}
	
	//return whether has extra shot
	public boolean getExtraShot()
	{
		return extraShotOfCoffee;
	}
	
	//return whether has extra syrup
	public boolean getExtraSyrup() {
		return extraShotOfSyrup;
	}
	
	//calculates price of coffee
	public double calcPrice() {
		//declare double variable to store price
		double coffeePrice = 0;
		//get the size of coffee by calling inherited method from Beverage
		SIZE tempSize = getSize();
		
		//add appropriate price to coffee based on size
		if (tempSize == SIZE.SMALL) {
			coffeePrice = 2;
			
			if (extraShotOfCoffee == true) {
				coffeePrice += .5;
			}
			if (extraShotOfSyrup == true) {
				coffeePrice += .5;
			}
		}
		else if (tempSize == SIZE.MEDIUM) {
			coffeePrice = 3;
			
			if (extraShotOfCoffee == true) {
				coffeePrice += .5;
			}
			if (extraShotOfSyrup == true) {
				coffeePrice += .5;
			}
		}
		else if (tempSize == SIZE.LARGE) {
			coffeePrice =4;
			
			if (extraShotOfCoffee == true) {
				coffeePrice += .5;
			}
			if (extraShotOfSyrup == true) {
				coffeePrice += .5;
			}
		}
		else {
			System.out.println("SOMETHING WENT WRONG COFFEE.JAVA");
			System.exit(-1);
		}
		return coffeePrice;
	}
	
	//prints out information about drink ordered
	public String toString() {
		return "Beverage Name:" + this.beverageName + ", Size:" + getSize() + "Contains extra shot: " + 
				this.extraShotOfCoffee +", Contains extra shot of Syrup: " + this.extraShotOfSyrup + 
				", Total Price: " + calcPrice();
	}
	
	//checks if 2 coffee ordered are the same
	public boolean equals(Object anotherBev) {
		
		if (this.beverageName.equals(((Beverage) anotherBev).getBevName())
				&& this.getType().equals(((Beverage) anotherBev).getType()) 
				&& this.getSize().equals(((Beverage) anotherBev).getSize())) {
			
			if(this.extraShotOfCoffee == ((Coffee) anotherBev).extraShotOfCoffee
					&& extraShotOfSyrup == ((Coffee) anotherBev).extraShotOfSyrup){
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
}















