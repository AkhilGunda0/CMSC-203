/*
 * Class: CMSC203 
 * Instructor: Dr. Tarek
 * Description: Creats abstract class beverage. its methods will be implements in its subclasses 
 * of different beverage types. 
 * Due: 12/6/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: __Akhil Gunda________
*/
public abstract class Beverage {
	protected String beverageName;
	protected TYPE enumBeverageType;
	protected SIZE enumBeverageSize;
	protected final double BASE_PRICE = 2.0;
	protected final double GO_UP_SIZE = 1.0;
	
	public Beverage(String name, TYPE type, SIZE size) {
		beverageName = name;
		enumBeverageType = type;
		enumBeverageSize = size;
	}
	
	public abstract double calcPrice();
	
	public String toString() {
		return "Beverage Name:" + this.beverageName + ", Beverage Size: " + enumBeverageSize;
	}
	
	public boolean equals(Object beverage2) {
		return (getBevName().equals(((Beverage) beverage2).getBevName()) 
				&& getType().equals(((Beverage) beverage2).getType()) 
				&& getSize().equals(((Beverage) beverage2).getSize()));		
	}
	
	public double getBasePrice() {
		return BASE_PRICE;
	}
	
	public TYPE getType() {
		return enumBeverageType;
	}
	
	public String getBevName() {
		return beverageName;
	}
	
	public SIZE getSize() {
		return enumBeverageSize;
	}
	
	public double addSizePrice() {
		return BASE_PRICE + GO_UP_SIZE;
	}
	
}
