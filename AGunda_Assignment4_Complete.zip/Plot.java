/*
 * Class: CMSC203 
 * Instructor: Dr. Tarek
 * Description: (Management Company class sets up a management 
 * company's plot of land, in which properties can be developed
 * property class adds property's in company's land
 * plot ensure that no properties overlap, and properties is within
 * company land)
 * Due: 10/24/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: ___Akhil Gunda_______
*/
public class Plot {

	private int x, y, width, depth;
	
	//default constructor
	public Plot() {
		width = 1;
		depth = 1;
		
	}
	
	//creates a plot using the given values
	public Plot(int x, int y, int width, int depth){
	this.x = x;
	this.y = y;
	this.width = width;
	this.depth = depth;
	}
	
	//copies otherPlot info into this plot
	public Plot(Plot otherPlot){
		x = otherPlot.x;
		y = otherPlot.y;
		width = otherPlot.width;
		depth = otherPlot.depth;
	}
	
	//setter and getter methods
	public void setX(int x2) {
		this.x = x2;
	}
	
	public int getX() {
		return x;
	}
	
	public void setY(int y2) {
		this.y = y2;
	}
	
	public int getY() {
		return y;
	}
	
	public void setWidth(int width2) {
		this.width = width2;
	}
	
	public int getWidth() {
		return width;
	}
	
	public void setDepth(int depth2) {
		this.depth = depth2;
	}
	
	public int getDepth() {
		return depth;
	}
	
	// if two plots overlap
	public boolean overlaps(Plot plot) {	
		
		//to help visualize, create starting points and ending points.
		//ending points of plot is the right and bottom points of the plot
		int startingX = x; 
		int startingX2 = plot.getX();
		int endingX = x + width; 
		int startingY = y; 
		int startingY2 = plot.getY();
		int endingY = y + depth; 
		int width1 = width;
		int width2 = plot.getWidth();
		int depth1 = depth;
		int depth2 = plot.getDepth();
		
		//bools to check all conditions to see if one plot encompasses another
		boolean bool1 = false;
		boolean bool2 = false;
		boolean bool3 = false;
		boolean bool4 = false;
		boolean bool5 = false;
		boolean bool6 = false;
		boolean bool7 = false;
		boolean bool8 = false;
		
		// to check if two plots overlap, make sure all the conditions are false to not be overlapping
		if ((startingX <= startingX2 && startingX2 < endingX) &&  (startingY <= startingY2 && startingY2 < endingY)){
			bool1 = true;
		}
		if ((startingX >= startingX2 && startingX < (startingX2 + width1)) &&  (startingY >= startingY2 && startingY < (startingY2 + depth2))){
			bool2 = true;
		}
		if ((startingX2 + width2) > startingX && (startingX2 + width2) < endingX && startingY <= startingY2 && startingY2 <= endingY){
			bool3 = true;
		}
		if (endingX > startingX2 && endingX < (startingX2 + width2) && startingY >= startingY2 && startingY <= (startingY2 + depth2)) {
			bool4 = true;
		}
		if (startingX <= startingX2 && startingX2 < endingX && (startingY2 + depth2) > startingY && (startingY2 + depth2) <= endingY) {
			bool5 = true;
		}
		if (startingX >= startingX2 && startingX < (startingX2 +  width2) && endingY > startingY2 && endingY <= (startingY2 + depth2)) {
			bool6 = true;
		}
		if (startingX < (startingX2 + width2) && (startingX2 +width2) <= endingX && startingY < (startingY2 + depth2) && (startingY2 + depth2) <= endingY) {
			bool7 = true;
		}
		if (endingX > startingX2 && endingX <= (startingX2 + width2) && endingY > startingY2 && endingY <= (startingY2 + depth2)) {
			bool8 = true;
		}
		
		//if any condition met, it overlaps. so return true. else return false
		if (bool1 || bool2 || bool3 || bool4 || bool5 || bool6 || bool7 || bool8) {
			return true;
		}
		else 
			return false;
		
	}
	
	//checks if one plot is inside another plot i.e. encompasses
	public boolean encompasses(Plot plot) {
	
		//to help visualize, create starting points and ending points.
		//ending points of plot is the right and bottom points of the plot
		
		//x
		int startingX = x; 
		int startingX2 = plot.getX();
		int endingX = x + width; 
		int endingX2 = plot.getX() + plot.getWidth();
		//y
		int startingY = y; 
		int startingY2 = plot.getY();
		int endingY = y + depth; 
		int endingY2 = plot.getY() + plot.getDepth();
		
		//bools to check all the conditions
		boolean bool1 = false;
		boolean bool2 = false;
		boolean bool3 = false;
		boolean bool4 = false;
		
		//check all the conditions required for plot to be inside declared land
		if (startingX2 >= startingX) {
			bool1 = true;
		}
		if (startingY2>= startingY) {
			bool2 = true;
		}
		if (endingX2 <= endingX) {
			bool3 = true;
		}
		if (endingY2 <= endingY) {
			bool4 = true;
		}
		
		if (bool1 && bool2 && bool3 && bool4) {
			return true;
		}
		else 
			return false;
	}
	//return starty point of plot (x,y) and its width and depth
	public String toString() {
		String toString = "" + x + "," + y + ","+width +","+ depth;
		return toString;
	}
	
	
	
	
}
