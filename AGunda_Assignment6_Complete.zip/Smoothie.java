/*
 * Class: CMSC203 
 * Instructor: Dr. Tarek
 * Description: Creates smoothie beverage type, extends Beverage class
 * Due: 12/5/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: __Akhil Gunda________
*/
public class Smoothie extends Beverage {
	private int numOfFruits;
	private boolean hasProteinPowder;
	private final double PPCOST = 1.5d;
	private final double MORE_FRUIT = .5d;
	
	//constructor that creates new beverage && stores numOfFruits and hasProteinPowder
	public Smoothie(String bevName, SIZE size, int numOfFruits, boolean addProtein) {
		//create  beverage
		super(bevName, TYPE.SMOOTHIE, size);
		
		//store numOfFruits && whether adding protein powder
		this.hasProteinPowder = addProtein;
		this.numOfFruits = numOfFruits;
	}
	
	//returns the number of fruits
	public int getNumOfFruits() {
		return numOfFruits;
	}
	
	//returns whether protein powder was added or not
	public boolean getAddProtien() {
		return hasProteinPowder;
	}
	
	//sets the number of fruits
	public void setNumOfFruits(int numOfFruits) {
		this.numOfFruits = numOfFruits;
	}
	
	//sets whether protein powder was added or not
	public void setAddProtein(boolean protein) {
		this.hasProteinPowder = protein;
	}
	
	//checks if two smoothies are the same
	public boolean equals(Object anotherBev) {
		if (this.beverageName.equals(((Beverage) anotherBev).getBevName())
				&& this.getType().equals(((Beverage) anotherBev).getType()) 
				&& this.getSize().equals(((Beverage) anotherBev).getSize())) {
			
			if(this.numOfFruits == ((Smoothie) anotherBev).numOfFruits
					&& hasProteinPowder == ((Smoothie) anotherBev).hasProteinPowder){
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	
	//calculates the price of the smoothie
	public double calcPrice() {
		// declare double variable to store price
		double smoothiePrice = 0;
		// get the size of coffee by calling inherited method from Beverage
		SIZE tempSize = getSize();

		// add appropriate price to coffee based on size
		if (tempSize == SIZE.SMALL) {
			smoothiePrice = 2;

			if (hasProteinPowder == true) {
				smoothiePrice += PPCOST;
			}
			if (numOfFruits > 0) {
				smoothiePrice += numOfFruits * MORE_FRUIT;
			}
		} else if (tempSize == SIZE.MEDIUM) {
			smoothiePrice = 3;

			if (hasProteinPowder == true) {
				smoothiePrice += PPCOST;
			}
			if (numOfFruits > 0) {
				smoothiePrice += numOfFruits * MORE_FRUIT;
			}
		} else if (tempSize == SIZE.LARGE) {
			smoothiePrice = 4;

			if (hasProteinPowder == true) {
				smoothiePrice += PPCOST;
			}
			if (numOfFruits > 0) {
				smoothiePrice += numOfFruits * MORE_FRUIT;
			}
		} else {
			System.out.println("SOMETHING WENT WRONG COFFEE.JAVA");
			System.exit(-1);
		}
		return smoothiePrice;
	}
	
	//returns all fields
	public String toString() {
		return "Beverage Name:" + this.beverageName + ", Size:" + getSize() + "Contains" + 
				this.numOfFruits +" fruits" +", has protein powder: " + this.hasProteinPowder + 
				", Total Price: " + calcPrice();
	}
	
	
}
