/*
 * Class: CMSC203 
 * Instructor: Dr. Tarek
 * Description: BevShop implements BevShopInterface
 * Due: 12/05/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: __Akhil Gunda________
*/
import java.util.ArrayList;

public class BevShop implements BevShopInterfce {
	private int numOfAlcoholDrink;
	private final int MAX_ALCOHOL_DRINKS = 3;
	private ArrayList<Order> orderList; 
	private final int MINIMUM_AGE = 21;
	private DAY orderDay; 
	private Customer cust;
	private ArrayList<Beverage> beverageList = new ArrayList<Beverage>();
	private Order order;

	public BevShop() {
		orderList = new ArrayList<Order>();
	}
	public boolean validTime(int time) {
		
		//checks to see if times is between 8 and 23 inclusive
		if (time <=23 && time >= 8 ) {
			return true;
		} else {
			return false;
		}
	}
	
	//gets max number of fruits
	public int getMaxNumOfFruits() {
		return MAX_FRUIT;
	}

	//gets min age for alchol
	public int getMinAgeForAlcohol() {
		return MINIMUM_AGE;
	}
	
	//checks if exceeded max number of fruits
	public boolean isMaxFruit(int numOfFruits) {
		if (numOfFruits > MAX_FRUIT) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public int getMaxOrderForAlcohol() {
		return MAX_ORDER_FOR_ALCOHOL;
	}
	
	//returns true if reached max alcholic drinks, returns false otherwise
	public boolean eligibleForMore() {
		int numberOfAlcoholicDrinks = this.order.findNumOfBeveType(TYPE.ALCOHOL);
		
		return numberOfAlcoholicDrinks < 3 ? true: false;
	}
	
	//returns the number of alcholic drinks for the current order
	public int getNumOfAlcoholDrink() {
		int numOfBeverages = beverageList.size();
		int numOfAlcoholDrinks = 0;
		for (int beverage = 0; beverage < numOfBeverages; beverage++) {
			if (TYPE.ALCOHOL.equals(beverageList.get(beverage))) {
				numOfAlcoholDrinks++;
			}
		}
		return numOfAlcoholDrinks;
	}
	
	//checks if age is valid for alcholic drinks
	public  boolean validAge(int age) {
		return age > MIN_AGE_FOR_ALCOHOL? true: false;
	}
	
	//starts new order 
	public void startNewOrder(int time, DAY day, String customerName, int customerAge) {
		//create new customer, so we can pass it in order
		Customer c = new Customer(customerName, customerAge);
		//set the order filed to new order
		this.order = new Order (time, day, c);
		//add order to array list of orders
		orderList.add(order);
	}
	//add a coffee to current order
	public void processCoffeeOrder(String bevName, SIZE size, boolean extraShot, boolean extraSyrup) {
		order.addNewBeverage(bevName, size, extraShot, extraSyrup);
	}
	
	//add a alcohol for current order
	public void processAlcoholOrder(String bevName, SIZE size) {

		this.order.addNewBeverage(bevName, size);
	}
	
	//add a smoothie to current order
	public void processSmoothieOrder(String bevName, SIZE size, int numOfFruits, boolean addProtien) {

		order.addNewBeverage(bevName, size, numOfFruits, addProtien);
	}
	
	//checks if order number exists and in what location
	public int findOrder(int orderNo) {
		
		//number of orders
		int numOfOrders = orderList.size();
		
		//loops through every order to find orderNo
		for (double order = 0; order < numOfOrders; order++) {
			if(orderNo == orderList.get((int)order).getOrderNo()) {
				return (int) order;
			}
		}
		//return -1 if order number doesn't exist
		return -1;
	}
	
	
	public double totalOrderPrice(int orderNo) {
		//number of orders
		int numOfOrder = orderList.size();
					
		double totalOrderPrice = 0;
		
		//loops through every order to find orderNo
		for (double order = 0; order < numOfOrder; order++) {
			if(orderNo == orderList.get((int)order).getOrderNo()) {
				totalOrderPrice += orderList.get((int)order).calcOrderTotal();
				
			}
		}
		return totalOrderPrice;
	}
	public double totalMonthlySale() {
		
		//number of orders
		int numOfOrder = orderList.size();
				
		//declare double variable to store total monthly sales
		double totalMonthlySale = 0;
		
		//for loop adding each order's total
		for (double order = 0; order < numOfOrder; order++) {
			totalMonthlySale += orderList.get((int)order).calcOrderTotal();
		}
		
		return totalMonthlySale;
	}
	
	public int totalNumOfMonthlyOrders() {
		return orderList.size();
	}
	
	
	public Order getCurrentOrder() {
		return this.order;
	}
	
	//return order at index
	public Order getOrderAtIndex(int index) {
		return orderList.get(index);
	}
	
	//sorts orderList array using selection sort
	public void sortOrders() {
		
		//number of orders
		int numOfOrders = orderList.size();
		
		//loops through every item and replace
		for (int startScan = 0; startScan < numOfOrders-1; startScan++) {
			int minIndex = startScan;
			for (int index = startScan+1; index < orderList.size(); index++) {
				if (orderList.get(index).getOrderNo() < orderList.get(minIndex).getOrderNo()) {
					minIndex = index;
					
				}
			}

			//swap ascending order
			Order useless = orderList.get(minIndex);
			orderList.set(minIndex, orderList.get(startScan));
			orderList.set(startScan, useless);
		}
	}
	
	//tostring returns info about all orders, and monthly sales total
	public String toString() {
		//number of orders
		int numOfOrder = orderList.size();
					
		String s1 = "";
		
		//loops through every order to get toString
		for (double order = 0; order < numOfOrder; order++) {
			s1 += orderList.get((int) order).toString();
		}
		
		return s1+ "\n total monthly sales: " + totalMonthlySale();
	}
	
	
	
	
	
	
}
