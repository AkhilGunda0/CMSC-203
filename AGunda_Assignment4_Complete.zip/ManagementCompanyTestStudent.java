/*
 * Class: CMSC203 
 * Instructor: Dr. Tarek
 * Description: (Management Company class sets up a management 
 * company's plot of land, in which properties can be developed
 * property class adds property's in company's land
 * plot ensure that no properties overlap, and properties is within
 * company land)
 * Due: 10/24/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: ___Akhil Gunda_______
*/
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ManagementCompanyTestStudent {
	ManagementCompany mc1;
	ManagementCompany mc2;
	Property prop1, prop2, prop3, prop4;
	
	@BeforeEach
	void setUp() throws Exception {
		mc1 = new ManagementCompany("Giant", "1234214", 4.0);
		mc2 = new ManagementCompany();
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testGetName() {
		assertEquals("Giant",mc1.getName());
	}

	@Test
	void testSetManagementCompanyName() {
		mc2.setManagementCompanyName("blueHouses");
		assertEquals("blueHouses", mc2.getName());
	}

	@Test
	void testGetTaxID() {
		assertEquals("1234214",mc1.getTaxID());
	}

	@Test
	void testSetTaxID() {
		mc2.setTaxID("9876");
		assertEquals("9876", mc2.getTaxID());
	}

	@Test
	void testAddPropertyProperty() {
		prop1 = new Property ("twin", "jewel", 1243, "Earth",2,2,2,2);		 
		assertEquals(mc1.addProperty(prop1),0,0);
	}

	@Test
	void testAddPropertyStringStringDoubleString() {
		prop2 = new Property ("big" , "coal" , 7989, "mine", 3,3,1,1);
		assertEquals(mc1.addProperty(prop2),0,0);
	}

	@Test
	void testAddPropertyStringStringDoubleStringIntIntIntInt() {
		prop3 = new Property ("comp", "comp", 2323, "comp", 6,6,1,1);
		assertEquals(mc1.addProperty(prop3),0,0);
	}

	@Test
	void testGetTotalRent() {
		assertEquals(0, mc1.getTotalRent(),0);
	}

	@Test
	void testGetHighestRentPropperty() {
		assertEquals(null,mc1.getHighestRentPropperty());
	}

	@Test
	void testRemoveLastProperty() {
		mc1.removeLastProperty();
		assertEquals(0, mc1.getPropertiesCount());
	}

	@Test
	void testIsPropertiesFull() {
		assertEquals(false, mc1.isPropertiesFull());
	}

	@Test
	void testGetPropertiesCount() {
		assertEquals(0,mc1.getPropertiesCount());
	}

	@Test
	void testIsManagementFeeValid() {
		assertEquals(true, mc1.isManagementFeeValid());
	}

	@Test
	void testToString() {
		assertTrue(mc1.toString().contains("Giant"));
	}

	@Test
	void testGetPlot() {
		prop4 = new Property ("chrysler", "california", 1212, "cal", 7,7,1,1);
		assertEquals("7,7,1,1",prop4.getPlot().toString());
	}

}
