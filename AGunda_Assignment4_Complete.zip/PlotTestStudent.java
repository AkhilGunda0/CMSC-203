/*
 * Class: CMSC203 
 * Instructor: Dr. Tarek
 * Description: (Management Company class sets up a management 
 * company's plot of land, in which properties can be developed
 * property class adds property's in company's land
 * plot ensure that no properties overlap, and properties is within
 * company land)
 * Due: 10/24/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: ___Akhil Gunda_______
*/
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PlotTestStudent {

	private Plot plot2, plot1, p3, p4;
	@BeforeEach
	void setUp() throws Exception {
		
		plot1 = new Plot(1,1,7,7);
		plot2 = new Plot(4,4,2,2);
		p3 = new Plot();
		p4 = new Plot(2,2,2,2);
	}
	// p2 is completely inside p1
	
	
	@AfterEach
	void tearDown() throws Exception {
		plot2=plot1=null;
	}

	@Test
	void testSetX() {
		p3.setX(8);
		assertEquals(8,p3.getX());	
	}

	@Test
	void testGetX() {
		assertEquals(4, plot2.getX());
	}

	@Test
	void testSetY() {
		p3.setY(5);
		assertEquals(5,p3.getY());
	}

	@Test
	void testGetY() {
		assertEquals(1, plot1.getY());
	}

	@Test
	void testSetWidth() {
		p3.setWidth(3);
		assertEquals(3,p3.getWidth());
	}

	@Test
	void testGetWidth() {
		assertEquals(2, plot2.getWidth());
	}

	@Test
	void testSetDepth() {
		p3.setDepth(3);
		assertEquals(3,p3.getDepth());
	}

	@Test
	void testGetDepth() {
		assertEquals(7, plot1.getWidth());
	}

	@Test
	void testOverlaps() {
		assertTrue(plot2.overlaps(plot1));
	}

	@Test
	void testEncompasses() {
		assertTrue(plot1.encompasses(plot2));
	}

	@Test
	void testToString() {
		assertEquals("4,4,2,2",plot2.toString());	
	}

}
